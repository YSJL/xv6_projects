#ifndef INCLUDE_TYPES_h_
#define INCLUDE_TYPES_h_

typedef unsigned int   uint;
typedef unsigned short ushort;
typedef unsigned char  uchar;
typedef uint pde_t;

#endif  //INCLUDE_TYPES_h_
