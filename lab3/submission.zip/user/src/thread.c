#include "user.h"

int thread_create(void *(*start_routine)(void *), void *arg) {
  return -1;
}
int thread_wait() {
  return -1;
}