#ifndef INCLUDE_TYPES_h_
#define INCLUDE_TYPES_h_

typedef unsigned long   size_t;

typedef unsigned int   uint;
typedef unsigned short ushort;
typedef unsigned char  uchar;
typedef uint pde_t;

#endif  //INCLUDE_TYPES_h_
